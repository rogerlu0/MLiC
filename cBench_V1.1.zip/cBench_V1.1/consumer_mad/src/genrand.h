#ifndef ESOUND_GENRAND_H
#define ESOUND_GENRAND_H 1

void esound_genrand(unsigned char *buffer, int buf_len);

#endif /* ESOUND_GENRAND_H */
